<?php 

$conn = mysqli_connect("localhost", "root", "", "tokoline") or die(mysqli_error($conn));

// if($conn) {
// 	echo "berhasil";
// } else {
// 	echo "gagal";
// }