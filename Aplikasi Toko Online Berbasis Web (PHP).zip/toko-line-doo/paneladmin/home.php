<h3><i class="fa fa-angle-right"></i> Selamat Datang <?= $_SESSION['nama_lengkap']; ?></h3>
<div class="row mt">
  <div class="col-lg-12">
    <p><pre>Aplikasi Website Sederhana Toko Online Dodo | Repost by <a href='https://stokcoding.com/' title='StokCoding.com' target='_blank'>StokCoding.com</a>
    </pre>.</p>
  </div>
</div>